import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { from } from 'rxjs';
import { DataService} from  '../data-service.service';


 
@Component({
  selector: 'search-flights',
  templateUrl: './search-flights.component.html',
  styleUrls: ['./search-flights.component.css']  
})
export class SearchFlightsComponent implements OnInit {

  loaded = false;
  searchForm: FormGroup;
  flightDetails: any;
  isReset: boolean = false;
  //form builder
  //SearchFormBuilderConfig: FormBuilderConfig;

  constructor(private dataService: DataService) { }

  ngOnInit() {

    this.searchForm = new FormGroup({ 
      departureAirportCode : new FormControl('',Validators.required),
      arrivalAirportCode : new FormControl('',Validators.required),
      departureDate : new FormControl('',Validators.required),
      returnDate : new FormControl('',Validators.required),
    });   
    setTimeout(() => {
      this.loadFlightDetails();
      this.loaded = true;
    }, 200);   
  }

 

  onSubmit(){
   
    let departureAirportCode  = this.searchForm.controls.departureAirportCode.value;
    let arrivalAirportCode  = this.searchForm.controls.arrivalAirportCode.value;
    let departureDate  = this.searchForm.controls.departureDate.value;
    let returnDate  = this.searchForm.controls.returnDate.value;   
    
    this.isReset = false;    
    let AirlineName = "Multi";  //added default filter in order to load less data 
    if(isNaN(this.flightDetails))
     this.flightDetails = this.dataService.flightDetails.filter(x=> x.AirlineName == AirlineName);
  }
  
  Reset(){
    this.isReset = true;
  }

  loadFlightDetails()
  {   
    this.dataService.getPost();
  }

}

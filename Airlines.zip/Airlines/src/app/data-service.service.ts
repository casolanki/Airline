import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()

export class DataService {
  baseURL: string
  http: any
  flightDetails : any;
  constructor(http: HttpClient) {
    this.http = http;
    this.baseURL = 'http://nmflightapi.azurewebsites.net/api/flight'; 
  }
  async getPost() {    
    if(!this.flightDetails && this.flightDetails == null) {
      this.http.get(this.baseURL).subscribe(data => {
        this.flightDetails = data;
      });
    }
    return this.flightDetails;
  }
}
